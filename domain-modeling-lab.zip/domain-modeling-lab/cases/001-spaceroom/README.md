# Case 001 — SpaceRoom

- 시작일: 2026-11-23
- 도메인: 공유 오피스 회의실 예약
- 진행: **STEP 1, 2 완료 / STEP 3 대기**

## 자료

| 문서 | 상태 |
|---|---|
| [01 요구사항](01-requirements.md) | 기획서 |
| [02 업무 규칙 추출](02-business-rules.md) | 완료 |
| [03 엔티티 후보](03-entity-discovery.md) | 완료 |
| [04 책임과 생명주기](04-lifecycle.md) | 미진행 |
| [05 관계와 카디널리티](05-relationships.md) | 미진행 |
| [06 속성·제약조건](06-constraints.md) | 미진행 |
| [07 시나리오 검증](07-scenario-validation.md) | 미진행 |
| [회고](reflection.md) | 중간 회고 |

## 주의

아직 최종 엔티티 목록이나 ERD는 확정하지 않았습니다. `사용자·회의실·예약·지점`은 검토 중인 잠정 후보입니다.
